package com.akki.ecom_cars;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcomCarsApplicationTests {

	@Test
	void contextLoads() {
	}

}
