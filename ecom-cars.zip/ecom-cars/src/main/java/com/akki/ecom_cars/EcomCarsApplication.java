package com.akki.ecom_cars;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcomCarsApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcomCarsApplication.class, args);
	}

}
